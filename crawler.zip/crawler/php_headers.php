<script type="text/javascript" src="a.js"></script>
<?php 

if(isset($_POST['searchbtn']))
{
//echo "sdsds'?page=search&target=".$_POST['selectweb']."&search=".$_POST['search']."'";

echo "<script>window.location.href='?page=search&target=".$_POST['selectweb']."&search=".$_POST['search']."'</script>";
}
?>


