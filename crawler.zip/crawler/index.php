<?php 
//error_reporting(0);
include"header/header.php";
include"controller/controller.php";
?>
<div class="container">
	<div class="row">
		<div class="col-sm-12" style="margin:20px 0px 20px 0px; border: 1px solid #ebebeb; padding: 15px" >
<?php 
include $include;
?>
</div></div></div>
<?php
	
include"footer/footer.php";
	?>