<?php
$page=$_GET['page'];

if($page=='home')
{
	 $include="view/home.php";

}

elseif($page=='pak')
{
	 $include="view/pakstyle.php";
}



elseif($page=='puma')
{
	 $include="view/puma.php";
}


elseif($page=='sport')
{
	 $include="view/sport.php";
}

elseif($page=='search')
{
	 $include="view/searchshoes.php";
}

elseif($page=='login')
{
	 $include="view/login.php";
}

elseif($page=='signup')
{
	 $include="view/signup.php";
}
else
{
	echo '<div class="ads-grid_shop">
		<div class="shop_inner_inf">
			<div class="error_page">
				<h4 style="color:red">404</h4>
				<p>page not found!</p>

				</div>
				</div>
				</div>';


}

 ?>