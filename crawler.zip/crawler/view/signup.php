<div class="modal-header">
    <h2 style="font-family: monospace; text-align: center;">Register yourself</h2>

              </div>

              <div class="col-sm-3"></div>
<div class="col-sm-8">
      
      <?php if(isset($_POST['signup']))
{
    $connect=mysql_connect("localhost","root","");
$db=mysql_select_db("crawler",$connect);
    
 $select="select * from User where Email='".$_POST['email1']."'";
    $pass=mysql_query($select);
    $rows=mysql_fetch_assoc($pass);

    
    if($_POST['email1']== $rows['Email'])
    {
        echo"<p style='margin-left:27;px;color:red'>email already exists</p>";
        

    }

 elseif($_POST['password1']=="" || $_POST['repassword']=="")
{
   
                    echo"<p style='margin-left:27px;color:red'>password cannot be empty</p>";
}

else if($_POST['password1']==$_POST['repassword'])
    {
        
     $insert="insert into user (Name,Email,Password) values(
    '".$_POST['Name']."',
    '".$_POST['email1']."',
    '".$_POST['password1']."'
    

    )";
    mysql_query($insert);
     $_SESSION['email']=$_POST['email1'];
  $session_user=$_SESSION['email'];
    



}
else
{
    
       echo"<p style='margin-left:27px;color:red'>password didn't match</p>";
      

}
}


?>
<style type="text/css">
   
</style>
      <div class="modal-body modal-body-sub_agile">
        <div class="col-md-8 modal_body_left modal_body_left1">
          <h2 class="agileinfo_sign" style="text-align: center;"><span></span></h2>
          <form  method="post">
            <div class="styled-input agile-styled-input-top">
              <label class="signlable">Name</label>
              <input type="text" name="Name" class="nodeinput" required autofocus="autofocus">
              <span></span></div>
            <div class="styled-input">
              <label class="signlable">Email</label>
              <input type="email" class="nodeinput" name="email1" required>
              <span></span></div>
            <div class="styled-input">
              <label class="signlable">Password</label>
              <input type="password" class="nodeinput" name="password1" required>
              <span></span></div>
            <div class="styled-input">
              <label class="signlable">Confirm Password</label>
              <input type="password" class="nodeinput" name="repassword" required>
              <span></span></div>
            <input type="submit" name="signup" class="btn btn-success" value="Sign Up" style="margin-top:10px;">
          </form>
          <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
      </div>
</div>
    <!-- //Modal content-->
<div class="col-sm-1"></div>
<span class=" clearfix"></span>